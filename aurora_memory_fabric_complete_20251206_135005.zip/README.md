# Aurora Memory Fabric Complete Bundle

## Overview

This bundle contains the complete Aurora Memory Fabric system - a hybrid multi-tier
memory architecture designed for persistent AI conversation and learning.

**Generated:** 2025-12-06 13:50:05
**Version:** 2.0-enhanced

## Bundle Contents

### 1. Backend System (TypeScript)

Located in `backend/`

- **aurora-memory-manager.ts** - Hybrid tiered memory management system
- **memory-routes.ts** - RESTful API routes for memory operations
- **persistent-memory.ts** - Persistent storage layer
- **session-manager.ts** - Conversation session management
- **websocket-server.ts** - Real-time communication

### 2. Frontend Dashboard (React)

Located in `frontend/`

- **memory-fabric.tsx** - Main memory visualization dashboard
- **AuroraDashboard.tsx** - System monitoring and control panel
- **chat-interface.tsx** - Conversation interface with memory integration

### 3. Database

Located in `database/`

- **corpus.db** - SQLite database with all memory data
- **corpus.db-wal** - Write-ahead log for concurrent access
- **corpus.db-shm** - Shared memory file

### 4. Python Intelligence

Located in `python_intelligence/`

- **core/memory_fabric.py** - Core memory fabric engine
- **conversation_intelligence.py** - Conversation pattern analysis
- **learning_engine.py** - Self-learning capabilities
- **knowledge_engine.py** - Knowledge extraction and storage

### 5. Knowledge Base

Located in `knowledge_base/`

- JSONL files containing learned patterns
- Autonomous command definitions
- System status records

### 6. Sessions & Backups

Located in `sessions/` and `backups/`

- Chat session history
- Memory state backups
- Conversation archives

## Installation

### Prerequisites

- Node.js 18+ with npm
- Python 3.10+
- SQLite 3.35+

### Setup

1. Extract the bundle:
   ```bash
   unzip aurora_memory_fabric_complete_20251206_135005.zip
   cd aurora_memory_fabric_complete_20251206_135005
   ```

2. Install backend dependencies:
   ```bash
   npm install
   ```

3. Install Python dependencies:
   ```bash
   pip install -r requirements.txt
   ```

4. Initialize the database:
   ```bash
   python python_intelligence/core/memory_fabric.py
   ```

5. Start the server:
   ```bash
   npm run dev
   ```

## API Reference

### Memory Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/memory/save` | POST | Save a memory entry |
| `/api/memory/recall` | GET | Recall memories by query |
| `/api/memory/facts` | GET | Get all stored facts |
| `/api/memory/stats` | GET | Get memory statistics |
| `/api/memory/context` | GET | Get current context summary |

### WebSocket Events

| Event | Direction | Description |
|-------|-----------|-------------|
| `memory:update` | Server->Client | Real-time memory updates |
| `memory:sync` | Client->Server | Request memory sync |
| `session:start` | Client->Server | Start new session |

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Aurora Memory Fabric                      │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ Short-Term  │─▶│  Mid-Term   │─▶│    Long-Term        │  │
│  │   Memory    │  │   Memory    │  │     Memory          │  │
│  │  (10 msgs)  │  │ (summaries) │  │   (milestones)      │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
│         │                │                    │              │
│         └────────────────┴────────────────────┘              │
│                          │                                   │
│                    ┌─────▼─────┐                             │
│                    │ Semantic  │                             │
│                    │  Search   │                             │
│                    └───────────┘                             │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │    Fact     │  │   Event     │  │    Conversation     │  │
│  │   Store     │  │    Log      │  │    Compartments     │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## Troubleshooting

### Common Issues

**1. Database locked error**
```
Solution: Ensure only one process accesses the database at a time.
Check for zombie processes: ps aux | grep python
```

**2. Memory not persisting**
```
Solution: Verify the data directory has write permissions.
chmod -R 755 data/
```

**3. WebSocket connection fails**
```
Solution: Check the server is running and port 5000 is accessible.
curl http://localhost:5000/api/health
```

**4. Embeddings not working**
```
Solution: The built-in embedder requires no external dependencies.
If using external embeddings, ensure API keys are configured.
```

### Debug Mode

Enable debug logging:
```bash
export AURORA_DEBUG=1
python python_intelligence/core/memory_fabric.py
```

## Configuration

### Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `AURORA_MEMORY_BASE` | `data/memory` | Memory storage path |
| `AURORA_DEBUG` | `0` | Enable debug logging |
| `AURORA_BACKUP_INTERVAL` | `3600` | Backup interval (seconds) |
| `AURORA_MAX_SHORT_TERM` | `10` | Max short-term entries |
| `AURORA_MAX_LONG_TERM` | `100` | Max long-term entries |

## License

MIT License - See LICENSE file for details.

## Support

For issues and feature requests, please open an issue in the repository.

---
Generated by Aurora Memory Fabric Bundle Generator v1.0
