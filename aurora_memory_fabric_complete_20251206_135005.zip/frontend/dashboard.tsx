'use client';

import AuroraFuturisticDashboard from '@/components/AuroraFuturisticDashboard';

export default function DashboardPage() {
  return <AuroraFuturisticDashboard />;
}