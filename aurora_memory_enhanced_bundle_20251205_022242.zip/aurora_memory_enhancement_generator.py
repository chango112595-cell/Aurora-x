#!/usr/bin/env python3
"""
Aurora Memory Fabric 2.0 - Enhancement Generator
=================================================

This script initializes and enhances the Aurora Memory Fabric 2.0 system.
Run this to integrate memory capabilities across the entire Aurora system.

Usage:
    python3 aurora_memory_enhancement_generator.py

Author: Aurora AI System
Version: 2.0-enhanced
"""

import os
import sys
import json
import shutil
import hashlib
from datetime import datetime
from pathlib import Path

# Add project root to path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from core.memory_manager import AuroraMemoryManager, get_memory_manager


def create_directory_structure():
    """Create the complete memory fabric directory structure"""
    print("[+] Creating Memory Fabric directory structure...")
    
    base = PROJECT_ROOT / "data" / "memory"
    directories = [
        base / "projects" / "Aurora-Main" / "conversations",
        base / "projects" / "Aurora-Main" / "semantic",
        base / "projects" / "Aurora-Main" / "events",
        PROJECT_ROOT / "backups",
    ]
    
    for d in directories:
        d.mkdir(parents=True, exist_ok=True)
        print(f"    Created: {d}")
    
    print("[OK] Directory structure ready")


def initialize_memory_system():
    """Initialize the memory system with base facts"""
    print("[+] Initializing Aurora Memory Fabric 2.0...")
    
    am = get_memory_manager(base=str(PROJECT_ROOT / "data" / "memory"))
    am.set_project("Aurora-Main")
    
    # Register core facts
    am.remember_fact("integration_date", datetime.now().isoformat())
    am.remember_fact("fabric_version", "2.0-enhanced")
    am.remember_fact("system_name", "Aurora Intelligence")
    am.remember_fact("project_root", str(PROJECT_ROOT))
    
    # Log initialization event
    am.log_event("fabric_init", "Aurora Memory Fabric 2.0 initialized and enhanced")
    am.save_message("system", "Aurora Memory Fabric 2.0 initialization complete.")
    
    print(f"[OK] Memory system initialized")
    print(f"     Project: {am.current_project}")
    print(f"     Session: {am.session_id}")
    
    return am


def create_backup():
    """Create initial backup of memory system"""
    print("[+] Creating initial memory backup...")
    
    am = get_memory_manager()
    backup_file = am.backup(backup_dir=str(PROJECT_ROOT / "backups"))
    
    print(f"[OK] Backup created: {backup_file}")


def verify_integrity():
    """Verify memory system integrity"""
    print("[+] Verifying memory system integrity...")
    
    am = get_memory_manager()
    checksums = am.verify_integrity()
    
    for path, checksum in checksums.items():
        if checksum.startswith("ERROR"):
            print(f"    [WARN] {path}: {checksum}")
        else:
            print(f"    [OK] {path}: {checksum[:16]}...")
    
    print("[OK] Integrity check complete")


def run_test():
    """Run a quick test of the memory system"""
    print("[+] Running memory system test...")
    
    am = get_memory_manager()
    
    # Test fact memory
    am.remember_fact("test_key", "test_value")
    result = am.recall_fact("test_key")
    assert result == "test_value", "Fact memory test failed"
    print("    [OK] Fact memory working")
    
    # Test message saving
    am.save_message("user", "Test message from enhancement generator")
    am.save_message("aurora", "Test response acknowledged")
    print("    [OK] Message saving working")
    
    # Test semantic recall
    results = am.recall_semantic("test message")
    print(f"    [OK] Semantic recall working ({len(results)} results)")
    
    # Test context summary
    context = am.get_context_summary()
    print(f"    [OK] Context summary working ({len(context)} chars)")
    
    # Get stats
    stats = am.get_stats()
    print(f"    [OK] System stats: {json.dumps(stats, indent=2)}")
    
    print("[OK] All tests passed!")


def generate_enhancement_bundle():
    """Generate a ZIP bundle of the enhancement"""
    print("[+] Generating enhancement bundle...")
    
    bundle_name = f"aurora_memory_enhanced_bundle_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    bundle_path = PROJECT_ROOT / bundle_name
    
    # Files to include
    files_to_bundle = [
        "core/__init__.py",
        "core/memory_manager.py",
        "aurora_memory_enhancement_generator.py",
    ]
    
    bundle_path.mkdir(exist_ok=True)
    
    for f in files_to_bundle:
        src = PROJECT_ROOT / f
        if src.exists():
            dst = bundle_path / f
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)
            print(f"    Added: {f}")
    
    # Create zip
    shutil.make_archive(str(bundle_path), "zip", bundle_path)
    shutil.rmtree(bundle_path)
    
    print(f"[OK] Bundle created: {bundle_name}.zip")


def main():
    """Main enhancement process"""
    print("=" * 60)
    print("AURORA MEMORY FABRIC 2.0 - ENHANCEMENT GENERATOR")
    print("=" * 60)
    print()
    
    try:
        create_directory_structure()
        print()
        
        am = initialize_memory_system()
        print()
        
        run_test()
        print()
        
        create_backup()
        print()
        
        verify_integrity()
        print()
        
        generate_enhancement_bundle()
        print()
        
        print("=" * 60)
        print("AURORA MEMORY FABRIC 2.0 ENHANCEMENT COMPLETE!")
        print("=" * 60)
        print()
        print("Memory Fabric Status:")
        print(json.dumps(am.get_stats(), indent=2))
        print()
        print("Next steps:")
        print("1. Restart Aurora workflows to activate Memory Fabric")
        print("2. Test with: Aurora, remember my name is [your name]")
        print("3. Later ask: Aurora, what's my name?")
        print()
        
    except Exception as e:
        print(f"[ERROR] Enhancement failed: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
