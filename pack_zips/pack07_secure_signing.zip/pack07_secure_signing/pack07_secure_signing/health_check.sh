#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack07_secure_signing] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack07_secure_signing] health OK"
