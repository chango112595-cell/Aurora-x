#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack07_secure_signing')
PY
