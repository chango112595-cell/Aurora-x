# pack07_secure_signing

Signing, verification, device identity & HSM hooks

Production-ready implementation.