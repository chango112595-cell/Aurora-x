#!/usr/bin/env bash
pkill -f 'pack07_secure_signing' || true
