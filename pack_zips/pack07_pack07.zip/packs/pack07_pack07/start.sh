#!/usr/bin/env bash
echo "Start stub"
exit 0
