#!/usr/bin/env bash
# default healthy
exit 0
