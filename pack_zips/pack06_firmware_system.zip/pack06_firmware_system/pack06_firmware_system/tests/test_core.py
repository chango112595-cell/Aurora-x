def test_info():
    from core.module import info
    r = info()
    assert r.get('pack') == 'pack06_firmware_system'
