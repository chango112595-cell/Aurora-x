#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack06_firmware_system] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack06_firmware_system] health OK"
