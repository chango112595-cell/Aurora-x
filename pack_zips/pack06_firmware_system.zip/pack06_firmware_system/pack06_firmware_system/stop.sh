#!/usr/bin/env bash
PIDS=$(pgrep -f "pack06_firmware_system" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
