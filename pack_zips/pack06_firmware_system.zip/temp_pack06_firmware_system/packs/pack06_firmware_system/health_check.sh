#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack06_firmware_system] health OK'
