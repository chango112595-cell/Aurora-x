#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack06_firmware_system')
PY
