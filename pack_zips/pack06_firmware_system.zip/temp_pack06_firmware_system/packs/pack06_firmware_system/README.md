# pack06_firmware_system

Firmware packager, flasher, hotswap flow

Production-ready implementation.