#!/usr/bin/env bash
echo "Stop stub"
exit 0
