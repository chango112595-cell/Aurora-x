#!/usr/bin/env bash
pkill -f 'pack12_toolforge' || true
