#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack12_toolforge] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack12_toolforge] health OK"
