#!/usr/bin/env bash
PIDS=$(pgrep -f "pack12_toolforge" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
