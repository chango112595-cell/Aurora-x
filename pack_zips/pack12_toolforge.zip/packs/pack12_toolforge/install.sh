#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack12_toolforge/data" && echo installed > "$(pwd)/packs/pack12_toolforge/data/installed.txt"
