#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack05_5J_state_persistence/data" && echo installed > "$(pwd)/packs/pack05_5J_state_persistence/data/installed.txt"
