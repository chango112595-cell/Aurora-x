#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack05_5J_state_persistence] health OK'
