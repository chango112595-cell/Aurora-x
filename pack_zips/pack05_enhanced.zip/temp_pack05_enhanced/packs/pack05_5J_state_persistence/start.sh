#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack05_5J_state_persistence')
PY
