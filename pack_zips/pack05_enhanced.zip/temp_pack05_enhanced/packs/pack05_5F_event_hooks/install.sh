#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack05_5F_event_hooks/data" && echo installed > "$(pwd)/packs/pack05_5F_event_hooks/data/installed.txt"
