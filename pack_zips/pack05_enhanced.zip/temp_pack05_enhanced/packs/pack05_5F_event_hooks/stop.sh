#!/usr/bin/env bash
pkill -f 'pack05_5F_event_hooks' || true
