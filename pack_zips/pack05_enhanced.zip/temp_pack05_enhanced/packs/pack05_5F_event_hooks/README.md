# pack05_5F_event_hooks

Plugin Event Hooks and Middleware

Production-ready implementation.