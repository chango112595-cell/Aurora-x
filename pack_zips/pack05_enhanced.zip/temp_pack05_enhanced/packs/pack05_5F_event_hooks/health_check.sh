#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack05_5F_event_hooks] health OK'
