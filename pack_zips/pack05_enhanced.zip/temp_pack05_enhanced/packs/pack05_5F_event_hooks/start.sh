#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack05_5F_event_hooks')
PY
