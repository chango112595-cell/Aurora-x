#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack05_5H_plugin_store')
PY
