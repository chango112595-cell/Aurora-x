#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack05_5H_plugin_store/data" && echo installed > "$(pwd)/packs/pack05_5H_plugin_store/data/installed.txt"
