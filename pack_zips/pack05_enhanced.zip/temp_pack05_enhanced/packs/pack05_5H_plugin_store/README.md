# pack05_5H_plugin_store

Plugin Store metadata/catalog and local index

Production-ready implementation.