#!/usr/bin/env bash
pkill -f 'pack05_5H_plugin_store' || true
