#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack05_5H_plugin_store] health OK'
