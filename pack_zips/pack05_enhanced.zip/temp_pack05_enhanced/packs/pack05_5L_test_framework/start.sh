#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack05_5L_test_framework')
PY
