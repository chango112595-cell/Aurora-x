#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack05_5L_test_framework/data" && echo installed > "$(pwd)/packs/pack05_5L_test_framework/data/installed.txt"
