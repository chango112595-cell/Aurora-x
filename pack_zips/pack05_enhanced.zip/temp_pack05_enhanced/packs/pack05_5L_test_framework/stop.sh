#!/usr/bin/env bash
pkill -f 'pack05_5L_test_framework' || true
