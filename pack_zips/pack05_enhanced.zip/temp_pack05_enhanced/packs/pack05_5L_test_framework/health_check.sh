#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack05_5L_test_framework] health OK'
