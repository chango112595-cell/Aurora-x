# pack05_5E_capability_system

Capability System - fine-grained capability engine for plugins

Production-ready implementation.