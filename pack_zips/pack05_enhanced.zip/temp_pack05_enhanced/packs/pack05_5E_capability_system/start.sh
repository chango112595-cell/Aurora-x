#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack05_5E_capability_system')
PY
