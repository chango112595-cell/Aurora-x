#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack05_5E_capability_system/data" && echo installed > "$(pwd)/packs/pack05_5E_capability_system/data/installed.txt"
