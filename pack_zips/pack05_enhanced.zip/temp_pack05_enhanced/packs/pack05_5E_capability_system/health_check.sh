#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack05_5E_capability_system] health OK'
