#!/usr/bin/env bash
pkill -f 'pack05_5E_capability_system' || true
