#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack05_5G_permissions_resolver] health OK'
