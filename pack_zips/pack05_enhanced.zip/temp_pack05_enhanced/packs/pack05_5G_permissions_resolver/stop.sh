#!/usr/bin/env bash
pkill -f 'pack05_5G_permissions_resolver' || true
