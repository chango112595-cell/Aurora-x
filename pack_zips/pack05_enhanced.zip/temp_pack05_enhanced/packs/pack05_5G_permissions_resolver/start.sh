#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack05_5G_permissions_resolver')
PY
