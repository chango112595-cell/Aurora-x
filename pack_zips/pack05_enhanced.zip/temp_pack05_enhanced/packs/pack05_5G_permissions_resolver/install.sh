#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack05_5G_permissions_resolver/data" && echo installed > "$(pwd)/packs/pack05_5G_permissions_resolver/data/installed.txt"
