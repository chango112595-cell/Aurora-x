#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack05_5I_versioning_upgrades/data" && echo installed > "$(pwd)/packs/pack05_5I_versioning_upgrades/data/installed.txt"
