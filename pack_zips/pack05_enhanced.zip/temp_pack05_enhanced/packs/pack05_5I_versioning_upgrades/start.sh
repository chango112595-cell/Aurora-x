#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack05_5I_versioning_upgrades')
PY
