#!/usr/bin/env bash
pkill -f 'pack05_5I_versioning_upgrades' || true
