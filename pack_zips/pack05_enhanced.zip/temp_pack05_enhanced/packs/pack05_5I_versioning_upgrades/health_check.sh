#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack05_5I_versioning_upgrades] health OK'
