# pack05_5I_versioning_upgrades

Plugin versioning and semantic upgrade engine

Production-ready implementation.