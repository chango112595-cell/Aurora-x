#!/usr/bin/env bash
pkill -f 'pack05_5K_diagnostics' || true
