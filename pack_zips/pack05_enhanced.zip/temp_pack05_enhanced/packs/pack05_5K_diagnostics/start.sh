#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack05_5K_diagnostics')
PY
