#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack05_5K_diagnostics/data" && echo installed > "$(pwd)/packs/pack05_5K_diagnostics/data/installed.txt"
