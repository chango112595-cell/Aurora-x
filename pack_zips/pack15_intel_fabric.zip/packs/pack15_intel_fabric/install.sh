#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack15_intel_fabric/data" && echo installed > "$(pwd)/packs/pack15_intel_fabric/data/installed.txt"
