"""Core module for pack15_intel_fabric"""
import time
def info():
    return {'pack':'pack15_intel_fabric','version':'0.1.0','ts':time.time()}
def health_check():
    return True
