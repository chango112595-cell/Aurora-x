#!/usr/bin/env bash
PIDS=$(pgrep -f "pack15_intel_fabric" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
