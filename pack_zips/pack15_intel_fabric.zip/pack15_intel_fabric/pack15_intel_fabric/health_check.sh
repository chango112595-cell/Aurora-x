#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack15_intel_fabric] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack15_intel_fabric] health OK"
