#!/usr/bin/env bash
PIDS=$(pgrep -f "pack09_compute_layer" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
