#!/usr/bin/env bash
pkill -f 'pack09_compute_layer' || true
