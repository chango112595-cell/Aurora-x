#!/usr/bin/env bash
pkill -f 'pack13_runtime_2' || true
