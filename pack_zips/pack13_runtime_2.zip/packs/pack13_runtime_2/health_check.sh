#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack13_runtime_2] health OK'
