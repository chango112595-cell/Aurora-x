def test_info():
    from core.module import info
    r = info()
    assert r.get('pack') == 'pack13_runtime_2'
