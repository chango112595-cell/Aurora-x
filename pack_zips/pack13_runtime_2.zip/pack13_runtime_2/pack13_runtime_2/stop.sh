#!/usr/bin/env bash
PIDS=$(pgrep -f "pack13_runtime_2" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
