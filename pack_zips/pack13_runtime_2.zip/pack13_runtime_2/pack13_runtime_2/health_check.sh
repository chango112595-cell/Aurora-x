#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack13_runtime_2] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack13_runtime_2] health OK"
