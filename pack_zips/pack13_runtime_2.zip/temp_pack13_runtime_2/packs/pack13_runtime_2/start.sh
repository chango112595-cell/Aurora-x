#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack13_runtime_2')
PY
