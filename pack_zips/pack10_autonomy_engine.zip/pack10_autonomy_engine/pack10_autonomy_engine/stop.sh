#!/usr/bin/env bash
PIDS=$(pgrep -f "pack10_autonomy_engine" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
