#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack10_autonomy_engine] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack10_autonomy_engine] health OK"
