#!/usr/bin/env bash
pkill -f 'pack08_conversational_engine' || true
