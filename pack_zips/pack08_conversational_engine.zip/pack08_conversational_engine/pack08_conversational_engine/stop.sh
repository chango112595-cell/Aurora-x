#!/usr/bin/env bash
PIDS=$(pgrep -f "pack08_conversational_engine" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
