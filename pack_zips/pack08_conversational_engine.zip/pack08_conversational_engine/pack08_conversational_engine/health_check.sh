#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack08_conversational_engine] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack08_conversational_engine] health OK"
