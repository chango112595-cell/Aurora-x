"""Core module for pack08_conversational_engine"""
import time
def info():
    return {'pack':'pack08_conversational_engine','version':'0.1.0','ts':time.time()}
def health_check():
    return True
