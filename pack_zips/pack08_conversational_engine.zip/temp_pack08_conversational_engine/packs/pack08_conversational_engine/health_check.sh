#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack08_conversational_engine] health OK'
