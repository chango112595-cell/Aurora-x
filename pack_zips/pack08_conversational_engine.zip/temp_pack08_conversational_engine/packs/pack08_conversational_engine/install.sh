#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack08_conversational_engine/data" && echo installed > "$(pwd)/packs/pack08_conversational_engine/data/installed.txt"
