#!/usr/bin/env bash
pkill -f 'pack11_device_mesh' || true
