#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack11_device_mesh] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack11_device_mesh] health OK"
