#!/usr/bin/env bash
PIDS=$(pgrep -f "pack11_device_mesh" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
