#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack11_device_mesh')
PY
