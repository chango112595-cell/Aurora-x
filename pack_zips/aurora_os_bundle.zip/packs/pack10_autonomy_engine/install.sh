#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack10_autonomy_engine/data" && echo installed > "$(pwd)/packs/pack10_autonomy_engine/data/installed.txt"
