#!/usr/bin/env bash
pkill -f 'pack10_autonomy_engine' || true
