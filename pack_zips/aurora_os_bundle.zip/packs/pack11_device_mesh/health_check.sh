#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack11_device_mesh] health OK'
