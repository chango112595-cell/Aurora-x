# pack11_device_mesh

Device mesh, telemetry, P2P graph

Production-ready implementation.