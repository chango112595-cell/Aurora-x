#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack11_device_mesh/data" && echo installed > "$(pwd)/packs/pack11_device_mesh/data/installed.txt"
