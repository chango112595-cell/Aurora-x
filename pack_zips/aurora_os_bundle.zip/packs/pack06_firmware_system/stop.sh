#!/usr/bin/env bash
pkill -f 'pack06_firmware_system' || true
