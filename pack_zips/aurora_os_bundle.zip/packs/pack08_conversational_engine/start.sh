#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack08_conversational_engine')
PY
