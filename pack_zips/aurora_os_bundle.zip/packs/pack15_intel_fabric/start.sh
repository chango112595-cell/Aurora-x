#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack15_intel_fabric')
PY
