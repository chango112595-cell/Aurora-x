#!/usr/bin/env bash
echo "Install stub for PACK"
exit 0
