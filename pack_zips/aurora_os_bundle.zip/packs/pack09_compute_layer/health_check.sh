#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack09_compute_layer] health OK'
