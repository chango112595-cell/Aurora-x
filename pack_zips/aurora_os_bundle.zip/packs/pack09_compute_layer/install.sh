#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack09_compute_layer/data" && echo installed > "$(pwd)/packs/pack09_compute_layer/data/installed.txt"
