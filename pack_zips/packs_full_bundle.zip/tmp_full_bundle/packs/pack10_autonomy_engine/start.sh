#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack10_autonomy_engine')
PY
