#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack10_autonomy_engine] health OK'
