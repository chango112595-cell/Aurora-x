#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack13_runtime_2/data" && echo installed > "$(pwd)/packs/pack13_runtime_2/data/installed.txt"
