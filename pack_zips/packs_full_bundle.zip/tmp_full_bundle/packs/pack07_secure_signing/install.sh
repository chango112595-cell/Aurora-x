#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack07_secure_signing/data" && echo installed > "$(pwd)/packs/pack07_secure_signing/data/installed.txt"
