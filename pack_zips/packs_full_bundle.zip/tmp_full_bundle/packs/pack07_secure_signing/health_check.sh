#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack07_secure_signing] health OK'
