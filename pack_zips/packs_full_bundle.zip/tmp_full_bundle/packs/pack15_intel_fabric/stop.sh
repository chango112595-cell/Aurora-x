#!/usr/bin/env bash
pkill -f 'pack15_intel_fabric' || true
