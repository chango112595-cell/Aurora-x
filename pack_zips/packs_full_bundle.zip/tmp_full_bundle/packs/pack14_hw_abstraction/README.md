# pack14_hw_abstraction

Universal hardware abstraction layer

Production-ready implementation.