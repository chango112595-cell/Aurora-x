def test_info():
    from core.module import info
    r = info()
    assert r.get('pack') == 'pack14_hw_abstraction'
