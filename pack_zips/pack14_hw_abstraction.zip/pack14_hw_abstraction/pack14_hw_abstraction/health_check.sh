#!/usr/bin/env bash
python3 - <<'PY' || { echo "[pack14_hw_abstraction] health FAIL"; exit 2; }
import sys
print('ok')
PY
echo "[pack14_hw_abstraction] health OK"
