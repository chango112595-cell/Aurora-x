"""Core module for pack14_hw_abstraction"""
import time
def info():
    return {'pack':'pack14_hw_abstraction','version':'0.1.0','ts':time.time()}
def health_check():
    return True
