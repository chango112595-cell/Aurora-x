#!/usr/bin/env bash
PIDS=$(pgrep -f "pack14_hw_abstraction" || true)
if [[ -n "$PIDS" ]]; then
  kill $PIDS || true
fi
