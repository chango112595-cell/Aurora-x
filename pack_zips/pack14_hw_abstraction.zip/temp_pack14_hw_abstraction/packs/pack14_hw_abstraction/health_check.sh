#!/usr/bin/env bash
python3 - <<'PY'
print('ok')
PY
echo '[pack14_hw_abstraction] health OK'
