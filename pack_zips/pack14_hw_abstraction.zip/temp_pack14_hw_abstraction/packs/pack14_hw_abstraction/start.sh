#!/usr/bin/env bash
python3 - <<'PY'
print('Starting pack14_hw_abstraction')
PY
