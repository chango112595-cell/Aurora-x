#!/usr/bin/env bash
pkill -f 'pack14_hw_abstraction' || true
