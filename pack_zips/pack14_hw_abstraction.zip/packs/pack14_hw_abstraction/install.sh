#!/usr/bin/env bash
set -euo pipefail
mkdir -p "$(pwd)/packs/pack14_hw_abstraction/data" && echo installed > "$(pwd)/packs/pack14_hw_abstraction/data/installed.txt"
