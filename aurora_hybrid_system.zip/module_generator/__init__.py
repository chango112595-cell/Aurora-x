from .generator import ModuleGenerator, CATEGORIES, CATEGORY_TEMPLATES
