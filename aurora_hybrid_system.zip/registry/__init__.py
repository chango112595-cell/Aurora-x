from .module_registry import ModuleRegistry
