import re
from datetime import datetime

def slugify(text: str) -> str:
    text = text.strip().lower()
    text = re.sub(r"[^a-z0-9\s_\-]", "", text)
    text = re.sub(r"\s+", "_", text)
    return text[:48] or "task"

def guess_func_name(prompt: str) -> str:
    words = re.findall(r"[a-zA-Z0-9]+", prompt.lower())
    if not words:
        return "generated_function"
    verbs = {"create","make","build","reverse","sum","add","classify","detect","parse","convert","generate","count","sort"}
    for i,w in enumerate(words):
        if w in verbs and i+1 < len(words):
            return f"{w}_{words[i+1]}"
    base = "_".join(words[:2]) if len(words)>1 else words[0]
    return re.sub(r"^[^a-zA-Z_]", "f_", base)

def english_to_spec(prompt: str):
    title_slug = slugify(prompt)
    func = guess_func_name(prompt)
    md = f"""# {title_slug}
@lang: python
@template: generic
@signature: {func}()

Goal: {prompt.strip()}

Inputs: None
Outputs: Return a value that satisfies the goal.
Constraints:
- No external network or file I/O.
- Keep it pure and deterministic.
Tests:
- Example 1: Sanity output must be non-empty.
- Example 2: Function must not raise exceptions.
"""
    fname = f"specs/requests/{title_slug}.md"
    return fname, md
