from pathlib import Path
from tools.english_to_spec import english_to_spec

def ensure_dirs() -> Path:
    p = Path("specs/requests")
    p.mkdir(parents=True, exist_ok=True)
    return p

def save_spec(prompt: str) -> Path:
    ensure_dirs()
    fname, md = english_to_spec(prompt)
    path = Path(fname)
    path.write_text(md, encoding="utf-8")
    return path
