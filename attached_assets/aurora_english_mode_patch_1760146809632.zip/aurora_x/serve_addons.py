import os, threading, subprocess, shlex
from flask import request, jsonify
from aurora_x.spec.auto_wrap import save_spec

def _spawn_compile(spec_path: str):
    cmd = f"python -m aurora_x.main --spec {shlex.quote(spec_path)}"
    subprocess.Popen(cmd, shell=True)

def attach(app):
    @app.post("/api/chat")
    def api_chat():
        data = request.get_json(force=True, silent=True) or {}
        prompt = (data.get("prompt") or "").strip()
        if not prompt:
            return jsonify({"ok": False, "err": "missing prompt"}), 400
        spec_path = save_spec(prompt)
        _spawn_compile(str(spec_path))
        return jsonify({"ok": True, "spec": str(spec_path)})

    @app.get("/api/approve")
    def api_approve():
        token = request.args.get("token","")
        if token != os.getenv("AURORA_APPROVE_TOKEN",""):
            return jsonify({"ok": False, "err":"unauthorized"}), 401
        run_id = request.args.get("run_id","")
        if not run_id:
            return jsonify({"ok": False, "err":"missing run_id"}), 400
        try:
            from aurora_x.orchestrator import approve_run_id
            approve_run_id(run_id)
            return jsonify({"ok": True, "run_id": run_id})
        except Exception as e:
            return jsonify({"ok": False, "err": str(e)}), 500
