# Aurora-X English Mode (Offline)
Adds:
- Plain-English → spec auto-wrapper (`/api/chat` POST)
- Generic fallback template so unknown templates never fail
- One-tap approval endpoint (`/api/approve?run_id=...&token=...`)

## Use
POST `{your-repl}/api/chat` with JSON:
{"prompt":"make a todo generator that returns a short string"}

Aurora saves a spec to `specs/requests/*.md` and starts synthesis.

Approve:
GET {your-repl}/api/approve?run_id=run-YYYYMMDD-HHMMSS&token=YOUR_TOKEN

Env:
- AURORA_APPROVE_TOKEN – set a long random secret.
