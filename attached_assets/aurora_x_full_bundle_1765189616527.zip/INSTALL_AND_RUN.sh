#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
echo "Full Aurora-X bundle installer — working in $ROOT"

# Unzip bundles
echo "Unpacking production bundle..."
unzip -o "$ROOT/aurora_x_production_bundle.zip" -d "$ROOT/aurora_x_production_bundle"

echo "Unpacking extras bundle..."
unzip -o "$ROOT/aurora_x_extras.zip" -d "$ROOT/aurora_x_extras"

echo "Merging into 'aurora_x_combined'..."
COMBINED="$ROOT/aurora_x_combined"
rm -rf "$COMBINED"
mkdir -p "$COMBINED"
cp -r "$ROOT/aurora_x_production_bundle/"* "$COMBINED/"
cp -r "$ROOT/aurora_x_extras/"* "$COMBINED/"

echo "Writing quickstart environment file..."
cat > "$COMBINED/.env" <<'ENV'
# Edit these values for your environment
ETCD_HOSTS=127.0.0.1:2379
AUTONOMY_LEVEL=balanced
SANDBOX_CPUS=0.5
SANDBOX_MEM_MB=256
SANDBOX_TIMEOUT_SEC=15
ENV

echo "Creating virtualenv and installing requirements..."
cd "$COMBINED"
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
if [ -f requirements.txt ]; then
  pip install -r requirements.txt
fi

echo "Ready. Example commands:"
echo "  cd $COMBINED"
echo "  source .venv/bin/activate"
echo "  # Run the HTTP incident endpoint locally:"
echo "  uvicorn aurora_nexus_v3.autonomy.http_service:app --host 0.0.0.0 --port 8080"
echo "  # Or run the autonomy CLI with an incident JSON:"
echo "  echo '{"module_id":"001","error":"timeout","autonomy_level":"balanced"}' | python -u aurora_nexus_v3/autonomy/prod_autonomy.py"
echo "Installer complete."
