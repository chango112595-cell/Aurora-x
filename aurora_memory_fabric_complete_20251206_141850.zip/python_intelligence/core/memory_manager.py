#!/usr/bin/env python3
"""
Aurora Memory Fabric 2.0 - Enhanced Hybrid Memory System
=========================================================

A self-organizing, multi-layer intelligence memory system designed for:
- Multi-project, multi-conversation recall
- Tiered hybrid memory (short, mid, long, semantic)
- Automatic summarization & compression
- Fact + event memory
- Context auto-classification
- Cross-module awareness (hooks into Core Intelligence)
- Vector-based semantic search
- Secure storage, integrity, and recovery

Memory Layers:
- Short-term: Immediate chat/task context (session-based)
- Mid-term: Task summaries & ongoing sub-projects (few sessions)
- Long-term: Major milestones, final states (persistent)
- Semantic Memory: Encoded embeddings for reasoning (persistent)
- Fact Memory: Key facts (user name, projects, etc.) (persistent)
- Event Memory: Logs, actions, and system changes (persistent)

Author: Aurora AI System
Version: 2.0-enhanced
"""

import json
import os
import hashlib
import shutil
import math
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any, Optional, List, Dict
from dataclasses import dataclass, asdict, field


@dataclass
class MemoryEntry:
    """Single memory entry with metadata"""
    id: str
    content: str
    role: str  # user, aurora, system
    timestamp: str
    layer: str  # short, mid, long, semantic, fact, event
    importance: float = 0.5
    tags: List[str] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)
    embedding: Optional[List[float]] = None


class SimpleEmbedder:
    """Lightweight embedding generator for semantic search"""
    
    def __init__(self, dimensions: int = 128):
        self.dimensions = dimensions
    
    def embed(self, text: str) -> List[float]:
        """Generate a simple bag-of-words hash embedding"""
        vec = [0.0] * self.dimensions
        words = text.lower().split()
        for i, word in enumerate(words):
            idx = hash(word) % self.dimensions
            vec[idx] += 1.0 * (1.0 / (i + 1))  # Position weighting
        
        # Normalize
        norm = math.sqrt(sum(x * x for x in vec)) or 1.0
        return [x / norm for x in vec]
    
    def similarity(self, a: List[float], b: List[float]) -> float:
        """Compute cosine similarity between two vectors"""
        dot = sum(x * y for x, y in zip(a, b))
        norm_a = math.sqrt(sum(x * x for x in a))
        norm_b = math.sqrt(sum(x * x for x in b))
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return dot / (norm_a * norm_b)


class AuroraMemoryManager:
    """
    Aurora Memory Fabric 2.0 - Full Hybrid Memory Management System
    
    Features:
    - Multi-layer memory (short, mid, long, semantic, fact, event)
    - Automatic compression and summarization
    - Multi-project compartmentalization
    - Semantic search with embeddings
    - Persistent storage with integrity checks
    - Automatic memory promotion based on importance
    """
    
    # Thresholds for automatic memory promotion
    SHORT_TERM_THRESHOLD = 10
    MID_TERM_THRESHOLD = 10
    
    def __init__(self, base: str = "data/memory"):
        self.base_path = Path(base)
        self.base_path.mkdir(parents=True, exist_ok=True)
        
        self.current_project = "Aurora-Main"
        self.embedder = SimpleEmbedder()
        
        # Memory layers (in-memory caches)
        self.short_term: List[MemoryEntry] = []
        self.mid_term: List[MemoryEntry] = []
        self.long_term: List[MemoryEntry] = []
        self.semantic_memory: List[MemoryEntry] = []
        self.fact_memory: Dict[str, Any] = {}
        self.event_memory: List[MemoryEntry] = []
        
        # Session tracking
        self.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        self.message_count = 0
        
        # Initialize project
        self._ensure_project_structure()
        self._load_persistent_memory()
        
        print(f"[Memory Fabric 2.0] Initialized for project: {self.current_project}")
        print(f"[Memory Fabric 2.0] Session ID: {self.session_id}")
    
    def _ensure_project_structure(self) -> None:
        """Create directory structure for current project"""
        project_path = self.base_path / "projects" / self.current_project
        (project_path / "conversations").mkdir(parents=True, exist_ok=True)
        (project_path / "semantic").mkdir(parents=True, exist_ok=True)
        (project_path / "events").mkdir(parents=True, exist_ok=True)
    
    def _get_project_path(self) -> Path:
        """Get path for current project"""
        return self.base_path / "projects" / self.current_project
    
    def _load_persistent_memory(self) -> None:
        """Load persistent memory from disk"""
        project_path = self._get_project_path()
        
        # Load fact memory
        fact_file = project_path / "fact_memory.json"
        if fact_file.exists():
            try:
                with open(fact_file, "r") as f:
                    self.fact_memory = json.load(f)
                print(f"[Memory Fabric 2.0] Loaded {len(self.fact_memory)} facts")
            except Exception as e:
                print(f"[Memory Fabric 2.0] Warning: Could not load facts: {e}")
        
        # Load long-term memory
        long_file = project_path / "long_term_memory.json"
        if long_file.exists():
            try:
                with open(long_file, "r") as f:
                    data = json.load(f)
                    self.long_term = [self._dict_to_entry(d) for d in data]
                print(f"[Memory Fabric 2.0] Loaded {len(self.long_term)} long-term memories")
            except Exception as e:
                print(f"[Memory Fabric 2.0] Warning: Could not load long-term: {e}")
        
        # Load mid-term memory
        mid_file = project_path / "mid_term_memory.json"
        if mid_file.exists():
            try:
                with open(mid_file, "r") as f:
                    data = json.load(f)
                    self.mid_term = [self._dict_to_entry(d) for d in data]
                print(f"[Memory Fabric 2.0] Loaded {len(self.mid_term)} mid-term memories")
            except Exception as e:
                print(f"[Memory Fabric 2.0] Warning: Could not load mid-term: {e}")
        
        # Load semantic memory
        semantic_file = project_path / "semantic" / "embeddings.json"
        if semantic_file.exists():
            try:
                with open(semantic_file, "r") as f:
                    data = json.load(f)
                    self.semantic_memory = [self._dict_to_entry(d) for d in data]
                print(f"[Memory Fabric 2.0] Loaded {len(self.semantic_memory)} semantic memories")
            except Exception as e:
                print(f"[Memory Fabric 2.0] Warning: Could not load semantic: {e}")
    
    def _save_persistent_memory(self) -> None:
        """Save persistent memory to disk"""
        project_path = self._get_project_path()
        
        # Save fact memory
        fact_file = project_path / "fact_memory.json"
        with open(fact_file, "w") as f:
            json.dump(self.fact_memory, f, indent=2)
        
        # Save long-term memory
        long_file = project_path / "long_term_memory.json"
        with open(long_file, "w") as f:
            json.dump([self._entry_to_dict(e) for e in self.long_term], f, indent=2)
        
        # Save mid-term memory
        mid_file = project_path / "mid_term_memory.json"
        with open(mid_file, "w") as f:
            json.dump([self._entry_to_dict(e) for e in self.mid_term], f, indent=2)
        
        # Save semantic memory
        semantic_file = project_path / "semantic" / "embeddings.json"
        with open(semantic_file, "w") as f:
            json.dump([self._entry_to_dict(e) for e in self.semantic_memory], f, indent=2)
    
    def _entry_to_dict(self, entry: MemoryEntry) -> Dict[str, Any]:
        """Convert MemoryEntry to dictionary"""
        return asdict(entry)
    
    def _dict_to_entry(self, d: Dict[str, Any]) -> MemoryEntry:
        """Convert dictionary to MemoryEntry"""
        return MemoryEntry(**d)
    
    def set_project(self, project_name: str) -> None:
        """Switch to a different project context"""
        # Save current project's memory first
        if self.current_project:
            self._save_persistent_memory()
        
        # Switch project
        self.current_project = project_name
        self._ensure_project_structure()
        
        # Clear ONLY session-based memory (short-term and events are session-based)
        # Persistent memory (facts, mid, long, semantic) will be reloaded
        self.short_term = []
        self.event_memory = []
        
        # Reset persistent memory containers before loading
        self.mid_term = []
        self.long_term = []
        self.semantic_memory = []
        self.fact_memory = {}
        
        # Load new project's persistent memory
        self._load_persistent_memory()
        
        print(f"[Memory Fabric 2.0] Switched to project: {project_name}")
    
    def save_message(self, role: str, content: str, importance: float = 0.5, 
                     tags: Optional[List[str]] = None) -> MemoryEntry:
        """Save a message to short-term memory"""
        entry = MemoryEntry(
            id=f"msg_{uuid.uuid4().hex[:12]}",
            content=content,
            role=role,
            timestamp=datetime.now().isoformat(),
            layer="short",
            importance=importance,
            tags=tags or [],
            metadata={
                "session_id": self.session_id,
                "message_number": self.message_count
            },
            embedding=self.embedder.embed(content)
        )
        
        self.short_term.append(entry)
        self.message_count += 1
        
        # Auto-compress if threshold reached
        if len(self.short_term) >= self.SHORT_TERM_THRESHOLD:
            self.compress_short_term()
        
        # Auto-save to conversation file
        self._save_conversation()
        
        return entry
    
    def remember_fact(self, key: str, value: Any, category: str = "general") -> None:
        """Store a persistent fact"""
        self.fact_memory[key] = {
            "value": value,
            "category": category,
            "timestamp": datetime.now().isoformat(),
            "importance": 1.0  # Facts are always important
        }
        self._save_persistent_memory()
        print(f"[Memory Fabric 2.0] Remembered fact: {key} = {value}")
    
    def recall_fact(self, key: str) -> Optional[Any]:
        """Recall a stored fact"""
        if key in self.fact_memory:
            return self.fact_memory[key]["value"]
        return None
    
    def get_all_facts(self) -> Dict[str, Any]:
        """Get all stored facts"""
        return {k: v["value"] for k, v in self.fact_memory.items()}
    
    def log_event(self, event_type: str, description: str, 
                  metadata: Optional[Dict[str, Any]] = None) -> MemoryEntry:
        """Log a system event"""
        entry = MemoryEntry(
            id=f"evt_{uuid.uuid4().hex[:12]}",
            content=description,
            role="system",
            timestamp=datetime.now().isoformat(),
            layer="event",
            importance=0.7,
            tags=[event_type],
            metadata=metadata or {},
            embedding=self.embedder.embed(description)
        )
        
        self.event_memory.append(entry)
        
        # Save event log
        self._save_event(entry)
        
        return entry
    
    def _save_event(self, entry: MemoryEntry) -> None:
        """Save event to event log file"""
        project_path = self._get_project_path()
        event_file = project_path / "events" / f"events_{datetime.now().strftime('%Y%m%d')}.jsonl"
        
        with open(event_file, "a") as f:
            f.write(json.dumps(self._entry_to_dict(entry)) + "\n")
    
    def _save_conversation(self) -> None:
        """Save current conversation to file"""
        project_path = self._get_project_path()
        conv_file = project_path / "conversations" / f"{self.session_id}.json"
        
        with open(conv_file, "w") as f:
            json.dump({
                "session_id": self.session_id,
                "project": self.current_project,
                "started": self.short_term[0].timestamp if self.short_term else None,
                "messages": [self._entry_to_dict(e) for e in self.short_term]
            }, f, indent=2)
    
    def compress_short_term(self) -> None:
        """Compress short-term memory into mid-term summary"""
        if len(self.short_term) < 3:
            return
        
        # Create summary of short-term messages
        messages = [e.content for e in self.short_term]
        summary = self._generate_summary(messages)
        
        # Calculate average importance
        avg_importance = sum(e.importance for e in self.short_term) / len(self.short_term)
        
        # Create mid-term entry
        mid_entry = MemoryEntry(
            id=f"mid_{uuid.uuid4().hex[:12]}",
            content=summary,
            role="summary",
            timestamp=datetime.now().isoformat(),
            layer="mid",
            importance=avg_importance,
            tags=["compressed", "conversation_summary"],
            metadata={
                "source_count": len(self.short_term),
                "session_id": self.session_id,
                "original_ids": [e.id for e in self.short_term]
            },
            embedding=self.embedder.embed(summary)
        )
        
        self.mid_term.append(mid_entry)
        
        # Keep only most recent short-term messages
        self.short_term = self.short_term[-3:]
        
        # Check if mid-term needs compression
        if len(self.mid_term) >= self.MID_TERM_THRESHOLD:
            self.compress_mid_term()
        
        # Save changes
        self._save_persistent_memory()
        
        print(f"[Memory Fabric 2.0] Compressed {len(messages)} messages into mid-term")
    
    def compress_mid_term(self) -> None:
        """Compress mid-term memory into long-term"""
        if len(self.mid_term) < 3:
            return
        
        # Create summary of mid-term entries
        summaries = [e.content for e in self.mid_term]
        long_summary = self._generate_summary(summaries, is_meta=True)
        
        # Calculate max importance
        max_importance = max(e.importance for e in self.mid_term)
        
        # Create long-term entry
        long_entry = MemoryEntry(
            id=f"long_{uuid.uuid4().hex[:12]}",
            content=long_summary,
            role="milestone",
            timestamp=datetime.now().isoformat(),
            layer="long",
            importance=max_importance,
            tags=["milestone", "project_memory"],
            metadata={
                "source_count": len(self.mid_term),
                "project": self.current_project
            },
            embedding=self.embedder.embed(long_summary)
        )
        
        self.long_term.append(long_entry)
        
        # Add to semantic memory for recall
        self.semantic_memory.append(long_entry)
        
        # Keep only most recent mid-term entries
        self.mid_term = self.mid_term[-3:]
        
        # Save changes
        self._save_persistent_memory()
        
        print(f"[Memory Fabric 2.0] Promoted to long-term memory")
    
    def _generate_summary(self, texts: List[str], is_meta: bool = False) -> str:
        """Generate a summary of multiple texts"""
        if not texts:
            return ""
        
        if is_meta:
            prefix = "Project milestone summary: "
        else:
            prefix = "Conversation summary: "
        
        # Simple extractive summary - take key phrases
        all_text = " ".join(texts)
        words = all_text.split()
        
        # Take first 100 words as summary
        summary_words = words[:100] if len(words) > 100 else words
        
        return prefix + " ".join(summary_words)
    
    def recall_semantic(self, query: str, top_k: int = 5) -> List[MemoryEntry]:
        """Search semantic memory for relevant entries"""
        query_embedding = self.embedder.embed(query)
        
        # Search across all memory layers with embeddings
        candidates = []
        
        for entry in self.semantic_memory + self.long_term + self.mid_term:
            if entry.embedding:
                score = self.embedder.similarity(query_embedding, entry.embedding)
                candidates.append((score, entry))
        
        # Sort by similarity and return top results
        candidates.sort(key=lambda x: x[0], reverse=True)
        return [entry for score, entry in candidates[:top_k] if score > 0.1]
    
    def recall_recent(self, count: int = 10) -> List[MemoryEntry]:
        """Recall most recent messages from all layers"""
        all_entries = self.short_term + self.mid_term
        all_entries.sort(key=lambda e: e.timestamp, reverse=True)
        return all_entries[:count]
    
    def contextual_recall(self, query: str) -> str:
        """Intelligent recall for conversational use"""
        # First check facts
        for key, data in self.fact_memory.items():
            if key.lower() in query.lower() or query.lower() in key.lower():
                return f"I remember: {key} = {data['value']}"
        
        # Then check semantic memory
        semantic_results = self.recall_semantic(query, top_k=3)
        if semantic_results:
            best = semantic_results[0]
            return f"Based on past knowledge: {best.content[:200]}"
        
        return ""
    
    def get_context_summary(self, max_tokens: int = 500) -> str:
        """Get a summary of current context for the AI"""
        parts = []
        
        # Add facts
        if self.fact_memory:
            facts_str = ", ".join([f"{k}={v['value']}" for k, v in self.fact_memory.items()])
            parts.append(f"Known facts: {facts_str}")
        
        # Add recent conversation context
        recent = self.recall_recent(5)
        if recent:
            conv_parts = [f"{e.role}: {e.content[:100]}" for e in recent]
            parts.append("Recent context: " + " | ".join(conv_parts))
        
        # Add project milestone if any
        if self.long_term:
            latest = self.long_term[-1]
            parts.append(f"Project milestone: {latest.content[:150]}")
        
        context = "\n".join(parts)
        
        # Truncate if too long
        words = context.split()
        if len(words) > max_tokens:
            context = " ".join(words[:max_tokens]) + "..."
        
        return context
    
    def backup(self, backup_dir: str = "backups") -> str:
        """Create a backup of all memory"""
        backup_path = Path(backup_dir)
        backup_path.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_file = backup_path / f"memory_backup_{timestamp}.zip"
        
        # Save all current memory first
        self._save_persistent_memory()
        
        # Create zip archive
        shutil.make_archive(
            str(backup_file).replace(".zip", ""),
            "zip",
            self.base_path
        )
        
        print(f"[Memory Fabric 2.0] Backup created: {backup_file}")
        return str(backup_file)
    
    def verify_integrity(self) -> Dict[str, str]:
        """Verify integrity of memory files"""
        checksums = {}
        project_path = self._get_project_path()
        
        for file_path in project_path.rglob("*.json"):
            try:
                with open(file_path, "rb") as f:
                    content = f.read()
                    checksum = hashlib.sha256(content).hexdigest()
                    checksums[str(file_path)] = checksum
            except Exception as e:
                checksums[str(file_path)] = f"ERROR: {e}"
        
        return checksums
    
    def get_stats(self) -> Dict[str, Any]:
        """Get memory system statistics"""
        return {
            "project": self.current_project,
            "session_id": self.session_id,
            "message_count": self.message_count,
            "short_term_count": len(self.short_term),
            "mid_term_count": len(self.mid_term),
            "long_term_count": len(self.long_term),
            "semantic_count": len(self.semantic_memory),
            "fact_count": len(self.fact_memory),
            "event_count": len(self.event_memory),
            "fabric_version": "2.0-enhanced"
        }
    
    def clear_session(self) -> None:
        """Clear session-based memory (short-term only)"""
        self.short_term = []
        self.message_count = 0
        self.session_id = f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        print(f"[Memory Fabric 2.0] Session cleared. New session: {self.session_id}")


# Singleton instance for global access
_memory_instance: Optional[AuroraMemoryManager] = None


def get_memory_manager(base: str = "data/memory") -> AuroraMemoryManager:
    """Get or create the global memory manager instance"""
    global _memory_instance
    if _memory_instance is None:
        _memory_instance = AuroraMemoryManager(base=base)
    return _memory_instance


if __name__ == "__main__":
    # Test the memory system
    print("=" * 60)
    print("Aurora Memory Fabric 2.0 - Test Run")
    print("=" * 60)
    
    am = AuroraMemoryManager()
    
    # Test fact memory
    am.remember_fact("user_name", "Kai")
    am.remember_fact("favorite_language", "Python")
    
    # Test message saving
    am.save_message("user", "Hello Aurora, how are you?")
    am.save_message("aurora", "I'm doing great! How can I help you today?")
    am.save_message("user", "Can you remember my name is Kai?")
    am.save_message("aurora", "Of course! I'll remember that your name is Kai.")
    
    # Test recall
    print("\nRecalling user_name:", am.recall_fact("user_name"))
    print("\nAll facts:", am.get_all_facts())
    
    # Test context summary
    print("\nContext summary:")
    print(am.get_context_summary())
    
    # Test stats
    print("\nMemory stats:")
    print(json.dumps(am.get_stats(), indent=2))
    
    print("\n" + "=" * 60)
    print("Memory Fabric 2.0 test complete!")
    print("=" * 60)
