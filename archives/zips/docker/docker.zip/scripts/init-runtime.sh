#!/usr/bin/env bash
echo init runtime