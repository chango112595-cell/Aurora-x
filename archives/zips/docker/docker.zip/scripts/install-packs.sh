#!/usr/bin/env bash
for p in ../packs/*; do echo install $p; done